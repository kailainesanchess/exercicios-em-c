#include <stdio.h>
#include <stdlib.h>


int main() {

    float horas, salarioMin, VD, valorHora, salarioBruto, imposto, salarioFinal;

    printf("Digite o numero de horas trabalhadas: ");
    scanf("%f", &horas);

    printf("Digite o valor do salario minimo: ");
    scanf("%f", &salarioMin);

    VD = salarioMin / 30;
    valorHora = VD / 8;
    salarioBruto = horas * valorHora;
    imposto = salarioBruto * 0.03;
    salarioFinal = salarioBruto - imposto;

    printf("Salario bruto: %.2f\n", salarioBruto);
    printf("Imposto (3%%): %.2f\n", imposto);
    printf("Salario a receber: %.2f\n", salarioFinal);


    return 0;
}
