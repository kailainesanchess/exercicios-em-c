#include <stdio.h>
#include <stdlib.h>

int main()
{
    float n1,n2,n3,media;

    printf("digite o primeiro numero:");
    scanf("%f",&n1);

    printf("digite o segundo numero:");
    scanf("%f",&n2);

    printf("digite o terceiro numero:");
    scanf("%f",&n3);

    media=(n1*2 +n2*3 + n3*5) /10;

    printf("A media ponderada dos numeros %.2f, %.2f e %.2f e %.2f\n", n1, n2, n3, media);



    return 0;
}
