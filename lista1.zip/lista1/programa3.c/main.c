#include <stdio.h>
#include <stdlib.h>

int main()
{
     int dias, semanas,sobra;

     printf("digite os numeros de dias:");
     scanf("%d", &dias);

     semanas= dias/7;
     sobra=dias%7;

     printf("%d semanas e %d \n", semanas, sobra);
    return 0;
}
