#include <stdio.h>
#include <stdlib.h>

int main()
{
    float B,b,h,area;

     printf("digite o valor da base maior");
     scanf("%f", &B);

     printf("digite o valor da base menor");
     scanf("%f", &b);

     printf("digite o valor da altura");
     scanf("%f", &h);

     area=((B+b)*h/2);


     printf("A area do trapezio e %.2f/n",area);



    return 0;
}
