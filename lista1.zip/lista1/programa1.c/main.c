#include <stdio.h>
#include <stdlib.h>

int main()
{
   float valorF , valorC;
    printf("digite o valor de F");
    scanf("%f", &valorF);

    valorC = (valorF = 32),(5/9.0);
    printf("o valor em c : % f",valorC);
    return 0;
}
